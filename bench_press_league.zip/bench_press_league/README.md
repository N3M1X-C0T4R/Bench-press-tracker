# Bench Press League

A phone-friendly web app for tracking friends' bench press PRs in pounds.

## What works
- Create a profile with name, body weight, starting bench and current PR
- Leaderboards for highest bench, bench/bodyweight ratio, and progress since starting
- Log lifts with date, body weight and notes; see lift history
- Export/import a JSON backup
- Local mode saves in the browser on the current device
- Optional Supabase connection for shared profiles and lift history across devices

## To try it
Open `index.html` in a browser. It can run in local mode, but local records are only on that device/browser.

## To enable shared syncing
1. Create a project at https://supabase.com/
2. Open the app's Settings screen and copy the provided SQL setup into Supabase SQL Editor; run it.
3. In Supabase Project Settings → API, copy the Project URL and the anon/public key.
4. Paste those into Settings in the app and connect.
5. Host `index.html` on a static host with HTTPS (for example GitHub Pages, Netlify, or Vercel), then share that URL with friends. Each friend opens the same URL and uses the same Supabase project URL/key.

IMPORTANT SECURITY NOTE:
The included SQL uses open policies so the simplest prototype works without accounts. That means anyone who has the public app URL and public anon key can read/change the league data. Use only for a non-sensitive test league with friends you trust. Before using it as a real public app, add Supabase Auth, invite-only access, and row-level security policies. Never put a Supabase service-role key in the app.

## Notes
- This is a web app that feels good on a phone; it is not yet published in the App Store.
- The first profile's current bench is recorded as its initial history entry.
- Progress is measured against the starting bench value entered when creating/editing the profile.
